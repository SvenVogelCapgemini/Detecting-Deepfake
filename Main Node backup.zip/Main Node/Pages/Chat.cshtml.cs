using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Main_Node.Pages;

public class ChatModel : PageModel
{
    public void OnGet()
    {
    }
}