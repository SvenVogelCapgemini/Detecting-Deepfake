﻿namespace Main_Node.Models
{
    public class Task
    {
        public string Id { get; set; }
        public string URL { get; set; }
        public string Methode { get; set; }
    }
}
